r = int(input("enter radius: "))
l = int(input("enter length: "))
b = int(input("enter breadth: "))
area_of_circle=3.14*r*r
area_of_rectangle =l*b
print(area_of_circle)
print(area_of_rectangle)

