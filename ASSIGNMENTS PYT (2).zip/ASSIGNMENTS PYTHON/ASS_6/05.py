array = [16, 18, 27, 16, 23, 21, 19]
# Reverse the array using reverse indexing
reversed_array = array[::-1]
# Output the result
print("Reverse Array elements =", reversed_array)
