def count_words_starting_with_t(string):

  words = string.split()
  count = 0
  for word in words:
    if word[0] == "T":
      count += 1

  return count

string = input("enetr string: ")
count = count_words_starting_with_t(string)
print(count)