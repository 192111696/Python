def convert_case(string, case):
  if case == "upper":
    return string.upper()
  elif case == "lower":
    return string.lower()
  else:
    raise ValueError("Invalid case: {}".format(case))
string = input("enter string: ")
uppercase_string = convert_case(string, "upper")
print(uppercase_string)
lowercase_string = convert_case(string, "lower")
print(lowercase_string)